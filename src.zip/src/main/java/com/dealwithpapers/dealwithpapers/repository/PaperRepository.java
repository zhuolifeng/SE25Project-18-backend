package com.dealwithpapers.dealwithpapers.repository;

import com.dealwithpapers.dealwithpapers.entity.Paper;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PaperRepository extends JpaRepository<Paper, Long> {
    
    // 通过标题查找论文（模糊匹配）
    List<Paper> findByTitleContainingIgnoreCase(String title);
    
    // 通过作者查找论文（模糊匹配）
    @Query("SELECT p FROM Paper p JOIN p.authors a WHERE LOWER(a) LIKE LOWER(CONCAT('%', :author, '%'))")
    List<Paper> findByAuthorContainingIgnoreCase(@Param("author") String author);
    
    // 通过摘要搜索
    List<Paper> findByAbstractTextContainingIgnoreCase(String abstractText);
    
    // 通过期刊名称搜索
    List<Paper> findByJournalContainingIgnoreCase(String journal);
    
    // 通过类别搜索
    List<Paper> findByCategoryContainingIgnoreCase(String category);
    
    // 根据DOI查找论文
    Paper findByDoi(String doi);
    
    // 综合搜索（ID、DOI、标题、作者、摘要、期刊、类别）
    @Query("SELECT DISTINCT p FROM Paper p LEFT JOIN p.authors a WHERE " +
           "CAST(p.id AS string) = :searchTerm OR " +
           "(p.doi IS NOT NULL AND (p.doi = :searchTerm OR LOWER(p.doi) LIKE LOWER(CONCAT('%', :searchTerm, '%')))) OR " +
           "LOWER(p.title) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
           "LOWER(a) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
           "LOWER(p.abstractText) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
           "LOWER(p.journal) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
           "LOWER(p.category) LIKE LOWER(CONCAT('%', :searchTerm, '%'))")
    List<Paper> searchByTerm(@Param("searchTerm") String searchTerm);
    
    // 通过年份搜索（单独方法）
    @Query("SELECT p FROM Paper p WHERE p.year = :year")
    List<Paper> findByYear(@Param("year") Integer year);
} 