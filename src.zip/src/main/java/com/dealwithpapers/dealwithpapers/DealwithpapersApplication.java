package com.dealwithpapers.dealwithpapers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DealwithpapersApplication {

    public static void main(String[] args) {
        SpringApplication.run(DealwithpapersApplication.class, args);
    }

}
